"use strict";

var hideIcon = true;
var isPopup = true;
window.pagename = 'popup';
var currentTabUrl = '';
var messagePop = new Message('popup');
var switchEl = document.getElementById('pagenote-switch');
checkNotification();
refreshStatus();
addMenuClickLisenter();
getCommands();
formatI18n();
sendPageView();

function refreshStatus() {
  messagePop.addListener('on_get_current_page_status', function (request, sender, sendResponse) {
    var injected = request.injected,
        available = request.available,
        lightCnt = request.lightCnt,
        keys = request.keys;
    currentTabUrl = request.url;
    var notes = request.notes;
    sendEvent('popup', 'get_status', 'show', available ? 'available' : '', lightCnt); // var tipEl = document.getElementById('injected');
    //
    // if (injected) {
    //   tipEl.classList.remove('hide');
    // } else {
    //   tipEl.classList.add('hide');
    // }

    var un_available = document.getElementById('un_available');
    un_available.classList.add('hide'); // 进入回调说明已经联通

    if (available) {
      document.body.classList.remove('un-available'); // document.getElementById('available-info').classList.remove('hide');
      // document.getElementById('light-info').classList.remove('hide');
      // document.getElementById('light-count').innerText = lightCnt || '0';

      document.getElementById('pagenote-switch').checked = true; // const note = document.querySelector('textarea');
      // note.style.display = 'block';
      // note.value = (notes.find((note)=>{
      //     return note.id==='body'
      // })||{tip:''}).tip;
      // note.addEventListener('input',function () {
      //      messagePop.sendMessageToFrontEnd('save_page_note',{
      //          note:note.value
      //      });
      // });
    } else {
      document.body.classList.add('un-available'); // un_available.classList.remove('hide');
    }

    switchEl.checked = available;
  }).sendMessageToFrontEnd('get_current_page_status'); // messagePop.sendMessageToBack('get_user_info',{},function (request) {
  //     const {user} = request;
  //     const userEl = document.getElementById('user');
  //     const loginEl = document.getElementById('login');
  //     if(!userEl && loginEl){
  //         return;
  //     }
  //     if(user){
  //         userEl.classList.remove('hide');
  //         userEl.innerText = user.name;
  //         userEl.href = 'https://pagenote.logike.cn/me';
  //         loginEl.classList.add('hide')
  //     }else{
  //         userEl.classList.add('hide');
  //         userEl.href = 'https://pagenote.logike.cn/';
  //         loginEl.classList.remove('hide')
  //     }
  // })
}

function checkNotification() {
  messagePop.sendMessageToBack('get_notification', {}, function (result) {
    if (result.notificationInfo) {
      var notifiEl = document.getElementById('notification-content');
      notifiEl.innerHTML = result.notificationInfo.text_zh;
      setTimeout(function () {
        messagePop.sendMessageToBack('read_notification_already', {});
      }, 2000);
      document.getElementById('got-notification').addEventListener('click', function () {
        trackEvent('notification', 'ready', result.notificationInfo.id, getCurrentVersion());
        messagePop.sendMessageToBack('read_notification_already', {
          times: 9999
        });
        notifiEl.innerHTML = '';
      });
      var highlights = result.notificationInfo.highlights || [];
      highlights.forEach(function (id) {
        var element = document.getElementById(id);

        if (element) {
          element.classList.add('notification');
        }
      });
    }
  });
}

function addMenuClickLisenter() {
  document.getElementById('open-share').onclick = function () {
    messagePop.sendMessageToFrontEnd('export');
  }; // document.getElementById('toggleLight').onclick = function () {
  //     messagePop.sendMessageToFrontEnd('toggleAllLight')
  // };


  document.getElementById('capture-page').onclick = function () {
    messagePop.sendMessageToBack('capture', {
      isAuto: false
    });
    window.close();
  };

  switchEl.onchange = function (e) {
    messagePop.sendMessageToFrontEnd('togglePagenote', {
      status: e.target.checked
    });
    switchEl.checked = false;
  };

  document.getElementById('goto-pagenote').onclick = function (e) {
    messagePop.sendMessageToBack('open_home');
    e.stopPropagation();
    e.preventDefault();
  };
}

function getCommands() {
  chrome.commands.getAll(function (commands) {
    commands.forEach(function (command) {
      var id = command.name + '-command';
      var el = document.getElementById(id);

      if (el) {
        el.innerText = command.shortcut;
      }
    });
  });
}
