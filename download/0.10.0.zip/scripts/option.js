"use strict";

window.pagename = 'option' + Math.random();
window.isOption = true;
var optionMessage = new Message('option');
optionMessage.addListener('on_get_setting', function (request, sender, sendResponse) {
  var setting = request.data; // 配色

  var currentColorItem = getColorsById(setting.themeId);
  document.getElementById(currentColorItem.id).checked = true; // 最大标记数
  // const maxNumber = setting.maxRecord || 50;
  // const showCountEl =
  //     document.getElementById('max-record');
  // showCountEl.innerText = maxNumber;
  // const rangeInput = document.getElementById('max-count')
  // rangeInput.value = maxNumber;
  // rangeInput.onchange = debounce((e)=>{
  //     const count = Number(e.target.value);
  //     rangeInput.value = count;
  //     showCountEl.innerText = count;
  //     optionMessage.sendMessageToBack('save_setting',{
  //         setting: {
  //             maxRecord: count
  //         }
  //     });
  // });
  // // 匹配规则
  // const type = setting.matchType || 'smart';
  // document.getElementById(type).checked = true;
  // const tipEl = document.getElementById('match-tip');
  // tipEl.innerText = getLocale(type+'_match_tip');
  // const matchTypeEls = document.getElementsByName('match_type');
  // [].forEach.call(matchTypeEls,function (ele) {
  //     ele.addEventListener('change',function (e) {
  //         const value = e.target.value;
  //         setting.matchType = value;
  //         tipEl.innerText = getLocale(value+'_match_tip');
  //         optionMessage.sendMessageToBack('save_setting',{
  //             setting: setting
  //         })
  //     })
  // });
}).sendMessageToBack('get_setting');
/*setting start*/

var menu = document.querySelector('.menu');

if (menu) {
  var isPrivacy = location.hash.indexOf('privacy') > -1;
  document.querySelector('.option').dataset.active = isPrivacy ? 'privacy-manager' : localStorage.getItem('menu-active') || 'privacy-manager';
  menu.addEventListener('click', function (e) {
    var target = e.target.dataset.name;

    if (target) {
      localStorage.setItem('menu-active', target);
      document.querySelector('.option').dataset.active = target;
    }
  });
} // 用户改进计划


var join = document.getElementById('join-promotion-tab');
var joinSetting = localStorage.getItem('join_promotion');

join.onclick = function (e) {
  var status = e.target.checked ? 'enable' : 'disable';
  localStorage.setItem('join_promotion', status);
  trackEvent('setting', 'change_analytics', status);
};

if (joinSetting === undefined || joinSetting !== 'disable') {
  join.checked = true;
} else {
  join.checked = false;
}

var colorContainer = document.querySelector('.color-types');
var colors = [{
  id: 'theme-default',
  label: '默认色',
  desc: '默认有多色，有深浅，半透明色',
  colors: ['rgba(114,208,255,0.88)', '#ffbea9', '#c8a6ff', '#6fe2d5', 'rgba(255,222,93,0.84)', 'rgba(251, 181, 214, 0.84)', 'rgba(0,0,0,0.5)']
}, {
  id: 'theme-1',
  label: '七彩风',
  desc: '赤橙黄绿蓝靛紫，适用于显著地为标记做分类',
  colors: ['#03a9f4', '#f44336', '#ff5722', '#ffc107', '#4caf50', '#673ab7', '#9c27b0']
}, {
  id: 'theme-2',
  label: '山水风',
  desc: '一套青色风，适用于重要程度区分',
  colors: ['#00bcd4', '#e0f7fa', '#80deea', '#26c6da', '#00acc1', '#00838f', '#006064']
}];

if (colorContainer) {
  var bgText = 'pagenote';
  colors.forEach(function (item) {
    var element = document.createElement('div');
    var checkElement = document.createElement('input');
    checkElement.type = 'radio';
    checkElement.name = 'color';
    checkElement.id = item.id;

    checkElement.onchange = function (e) {
      var themeId = e.target.id;
      message.sendMessageToBack('save_setting', {
        setting: {
          themeId: themeId,
          colors: getColorsById(themeId).colors
        }
      });
      trackEvent('setting', 'changeColorTheme', '', themeId);
    };

    var inputHTML = "<label for=\"".concat(item.id, "\">").concat(item.label, "</label>");
    var colorHtml = '';
    item.colors.forEach(function (color, index) {
      var text = bgText[index];
      colorHtml += "<span class=\"color-item\" style='background:".concat(color, "'>").concat(text, "</span>");
    });
    var colorElement = document.createElement('span');
    colorElement.innerHTML = inputHTML + '<span>' + colorHtml + '<span style="color:#666;font-size: 12px">' + item.desc + '</span>' + '</span>';
    element.append(checkElement, colorElement);
    colorContainer.appendChild(element);
  });
}

showVersion();
sendPageView();

function getColorsById(id) {
  var colorItem = colors.find(function (item) {
    return item.id == id;
  }) || colors[0];
  return colorItem;
}

function showVersion() {
  document.getElementById('current_version').innerText = getCurrentVersion();
}
