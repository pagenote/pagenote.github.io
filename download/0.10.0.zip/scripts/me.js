"use strict";

var message = new Message('me');
var customEvent = document.createEvent('Event');
customEvent.initEvent('sync_data', true, true);

function sendPageNoteDatas(data) {
  var hiddenDiv = document.getElementById('bridge');

  if (hiddenDiv) {
    hiddenDiv.innerText = data;
    hiddenDiv.dispatchEvent(customEvent);
  }
}

message.addListener('on_get_pagenote_data', function (response) {
  sendPageNoteDatas(JSON.stringify(response.data));
}).sendMessageToBack('get_pagenote_data');
var bridge = document.getElementById('bridge');

if (bridge) {
  bridge.addEventListener('get_data', function () {
    message.sendMessageToBack('get_pagenote_data');
  });
  bridge.addEventListener('save_page', function (e) {
    var eventData = e.target.innerText;
    var data = {};

    try {
      data = JSON.parse(eventData);
    } catch (e) {}

    var message = new Message('me');
    message.sendMessageToBack('save_info', {
      data: data.data,
      key: data.key,
      keys: data.keys,
      plainData: data.plainData
    }, function (response) {
      message.sendMessageToBack('get_pagenote_data');
    });
  });
}
