"use strict";

window.pagename = 'new-tab';
var know = localStorage.getItem('iknow-why-new-tab');
var tipEl = document.getElementById('why-show-me');

if (know) {
  tipEl.classList.add('hide');
} else {
  tipEl.classList.remove('hide');
}

document.getElementById('iknow').onclick = function () {
  localStorage.setItem('iknow-why-new-tab', 'yes');
  tipEl.classList.add('hide');
};

sendPageView();
