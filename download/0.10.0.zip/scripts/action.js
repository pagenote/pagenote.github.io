"use strict";

(function () {
  var lightsCount = 0,
      darkCount = 0;

  if (!window.pagenote) {
    initPageNote();
    return;
  }

  window.pagenote.recordedSteps.forEach(function (step) {
    if (step.isActive) {
      lightsCount++;
    } else {
      darkCount++;
    }
  });
  var highlight = darkCount >= lightsCount;
  window.pagenote.replay(0, false, highlight, true);
})();
