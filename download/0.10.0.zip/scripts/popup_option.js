"use strict";

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

var clientName = window.pagename;
var message = new Message(clientName); // const FILTER_KEY = 'filter-keys_'+clientName
// const inputElement = document.getElementById('key');
// inputElement.placeholder = getLocale('search_placeholder');
// inputElement.value = localStorage.getItem(FILTER_KEY)||'';
// inputElement.addEventListener('input',debounce(function (e) {
//     filter();
// },200));
// document.getElementById('clean-keywords').addEventListener('click',function () {
//     inputElement.value = '';
//     filter();
// });

loadData();
initBackup();
var emptyTip = document.createElement('p');
emptyTip.innerText = getLocale('empty_filter_result');
emptyTip.id = 'filter-empty-tip';
emptyTip.style.textAlign = 'center';
emptyTip.className = 'hide';
var pageObject = {};
var storeDatas = null;

if (!window.isPopup) {// batchInit();
}

function loadData() {
  message.addListener('on_get_pagenote_data', function (response) {
    var requestClient = response.requestClient;

    if (requestClient !== clientName) {
      // 判断响应对象和请求对象是同一个
      return;
    }

    var datas = response.data;
    storeDatas = datas;
    return; // const currentUrl = response.currentUrl;

    var pages = [];
    Object.keys(datas).forEach(function (key) {
      var currentPage = datas[key];

      try {
        var tempObject = {
          href: key,
          // 兼容历史数据，6月份之后可以考虑不再支持历史数据
          data: _typeof(datas[key]) === 'object' && currentPage.plainData ? currentPage.plainData : decryptedData(_typeof(datas[key]) === 'object' ? datas[key].data : datas[key])
        };
        pageObject[key] = tempObject;
        pages.push(tempObject);
      } catch (e) {}
    }); // pages.sort(function (a,b) {
    //     if(a.data.url===currentUrl){
    //         return -1;
    //     }
    //     else if(a.data.url.substring(0,20)===currentUrl.substring(0,20)){
    //         return -1;
    //     }
    //     else if(b.data.url === currentUrl) {
    //         return 1
    //     } else if(b.data.url.substring(0,20)===currentUrl.substring(0,20)){
    //         return 1;
    //     }
    //     else {
    //         return b.data.lastModified ? b.data.lastModified - a.data.lastModified : (b.data.steps||[]).length - (a.data.steps||[]).length;
    //     }
    // });

    var tagsContainer = document.getElementById('tags');
    var container = document.createElement('div');

    if (pages.length > 0) {
      tagsContainer.innerHTML = '';
    } else {
      tagsContainer.innerText = getLocale('empty_tags');
    }

    var colors = {
      toggle: 0
    };
    pages.forEach(function (mark) {
      var steps = mark.data.steps || [];
      var url = mark.data.url;
      var title = mark.data.title || '';
      var snapshot = mark.data.snapshot;
      var images = mark.data.images || [];
      var icon = !window.hideIcon || window.currentTabUrl === url ? mark.data.icon : ''; // 匹配规则统一处理

      var element = document.createElement('div');
      element.className = 'mark-item';
      var tags = steps.map(function (step) {
        var link = url || mark.href; // TODO 打开时定位到锚点

        var color = step[5];
        colors.toggle++;
        colors[color] = (colors[color] || 0) + 1; // 直接记录在页面维度上

        var keyword = step[3];
        var note = step[4];
        return "<span title=\"".concat(keyword, "\" target=\"_blank\" href=\"").concat(link, "\" class=\"light-item\"\n                    data-color=\"").concat(color, "\"\n                    style=\"background-color: ").concat(color, ";\">").concat(note, "</span>");
      });
      var imagesEl = '';

      if (!window.isPopup && images[0]) {
        imagesEl += '<img class="thumbnail" src=' + images[0] + ' data-zoom="1" data-caption=' + title + ' />';
      }

      var lastTime = '';

      try {
        lastTime = new Date(mark.data.lastModified || steps[steps.length - 1][6]).toLocaleDateString();
      } catch (e) {}

      var snapshotEl = snapshot && !window.isPopup ? "<span class=\"snapshot-button\" data-snapshot=\"".concat(snapshot, "\">").concat(getLocale('snapshot'), "</span> ") : '';
      var inner = "<input style=\"position: absolute;left: -14px;\" type=\"checkbox\" class=\"page-check\" data-key=\"".concat(mark.href, "\" />");
      inner += "<div><a style=\"background-image: url(".concat(icon, ");padding-left: ").concat(icon ? '16px' : '', "\" href=\"").concat(url, "\" target=\"_blank\" class=\"page-title\">").concat(title, "</a></div> <a title=\"").concat(title, "\" target=\"_blank\" class=\"link-item\" href=\"").concat(mark.href, "\">").concat(mark.href, "</a>\n                            <div style=\"display: flex\"><div>").concat(imagesEl, "</div><div class=\"lights-container\" style=\"margin-top: 4px;\">").concat(tags.join(' '), " <span style=\"color: #999;font-size: 12px;\">").concat(lastTime, "</span> ").concat(snapshotEl, " </div></div>");
      element.innerHTML = inner;
      var deleteIcon = document.createElement('i');
      deleteIcon.title = getLocale('delete_page', 'delete');
      deleteIcon.className = 'icon trash';

      deleteIcon.onclick = function () {
        deleteItem(mark.href, element, !!icon);
      };

      element.appendChild(deleteIcon);
      var exportIcon = document.createElement('i');
      exportIcon.title = getLocale('export_md', 'export_md');
      exportIcon.className = 'export icon';

      exportIcon.onclick = function () {
        exportMd([mark]);
      };

      var exportFileIcon = document.createElement('i');
      exportFileIcon.title = getLocale('export', 'export');
      exportFileIcon.className = 'export-data icon';
      exportFileIcon.dataset.exportkey = url;

      exportFileIcon.onclick = function () {
        exportFile(exportFileIcon);
      };

      element.appendChild(exportFileIcon);
      element.appendChild(exportIcon);
      container.append(element);
    });
    tagsContainer.appendChild(container);
    tagsContainer.appendChild(emptyTip);
    var colorFilterContainer = document.getElementById('color-filter');
    Object.keys(colors).sort(function (a, b) {
      return colors[a] - colors[b] || a === 'toggle';
    }).forEach(function (color, index) {
      var filterColor = document.createElement('div');
      filterColor.className = 'filter-color-item';
      filterColor.style.backgroundColor = color;
      filterColor.dataset.count = colors[color];
      filterColor.dataset.color = color;
      var activeColors = localStorage.getItem('disable-colors') || '';

      if (color === 'toggle') {
        filterColor.classList.add('toggle-colors');

        filterColor.onclick = function () {
          var flat = true;
          return function () {
            [].forEach.call(document.querySelectorAll('.filter-color-item'), function (item) {
              if (flat) {
                item.classList.remove('active');
              } else {
                item.classList.add('active');
              }
            });
            flat = !flat;
            filter();
          };
        }();
      } else {
        if (activeColors.indexOf(color) === -1) {
          filterColor.classList.add('active');
        }

        filterColor.onclick = function () {
          filterColor.classList.toggle('active');
          filter();
        };
      } // filterColor.style.left = -12*index + 'px';


      colorFilterContainer.appendChild(filterColor);
    });
    setTimeout(function () {
      inputElement.focus();
    }, 100);
    filter();
  }).sendMessageToBack('get_pagenote_data');
}

function filter() {
  var inputValue = document.getElementById('key').value.trim();
  localStorage.setItem(FILTER_KEY, inputValue);
  var colorFilters = document.querySelectorAll('.filter-color-item');
  var activeColors = [];
  var disableColors = [];

  for (var i = 0; i < colorFilters.length; i++) {
    if (colorFilters[i].classList.contains('active')) {
      activeColors.push(colorFilters[i].dataset.color);
    } else {
      disableColors.push(colorFilters[i].dataset.color);
    }
  }

  localStorage.setItem('disable-colors', disableColors.toString());
  var items = document.querySelectorAll('.mark-item');
  var count = 0;
  items.forEach(function (item) {
    // 关键词筛选
    var keywords = inputValue.split(" ");
    var keywordCount = 0;

    for (var _i = 0; _i < keywords.length; _i++) {
      var word = keywords[_i].trim();

      if (!word) {
        keywordCount++;
        break;
      }

      var k = word.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
      var kReg = new RegExp(k, 'ig');

      if (kReg.test(item.innerText)) {
        keywordCount++;
      }
    } // 颜色筛选


    var colorMatchCount = 0;
    var tags = item.querySelectorAll('.light-item');

    for (var _i2 = 0; _i2 < tags.length; _i2++) {
      var _item = tags[_i2];

      if (activeColors.includes(_item.dataset.color)) {
        colorMatchCount++;
        break;
      }
    }

    if (keywordCount > 0 && colorMatchCount > 0) {
      item.style.display = 'block';
      count++;
    } else {
      item.style.display = 'none';
    }
  });

  if (count === 0) {
    emptyTip.classList.remove('hide');
  } else {
    emptyTip.classList.add('hide');
  }

  trackEvent('tags', 'search', count);
}

function deleteItem(key, element) {
  var reInitPageNote = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
  message.sendMessageToBack('save_info', {
    key: key,
    data: null
  }, function () {
    if (reInitPageNote && window.isPopup) {
      message.sendMessageToFrontEnd('on_get_data', {
        data: ''
      }); // TODO 查询key的tab 通知其clean data
    }

    element.parentNode.removeChild(element);
  });
}

function decryptedData(data) {
  var result = {};

  try {
    result = JSON.parse(decodeURI(atob(data)));
  } catch (e) {}

  return result;
}

function debounce(fn) {
  var interval = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 300;
  var timeout = null;
  return function () {
    var _arguments = arguments,
        _this = this;

    clearTimeout(timeout);
    timeout = setTimeout(function () {
      fn.apply(_this, _arguments);
    }, interval);
  };
}

function exportMd() {
  var pages = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
  var content = '';
  var markCount = 0;
  if (pages.length === 0) return;
  pages.forEach(function (page) {
    var steps = page.data.steps;
    var url = page.data.url;
    var title = page.data.title || url;
    content += "## [".concat(title, "](").concat(url, ")\n");
    steps.forEach(function (step) {
      var recordInfo = [step[0], step[1], step[2]];
      var time = new Date(step[6]).toLocaleDateString();
      var refer = step[3] || '';
      var note = step[4] || '';
      var id = step[2];

      if (note !== refer) {
        content += "".concat(note, "\n");
      }

      content += "> ".concat(refer, "\n\n"); // [${time}](${recordInfo})

      markCount++;
    });
    content += '\n';
  });
  content += '## [标记统计](https://logike.cn/pagenote)\n';
  content += '| 页面数 | 标记数 | 平均标记/页面 |\n';
  content += '| :--- | :---| :--- |\n';
  content += "| ".concat(pages.length, "  | ").concat(markCount, " |  ").concat(Math.floor(markCount / pages.length), "   |\n");
  var name = "pagenote[".concat(markCount, "lights]");
  funDownload(content, name + '.md');
  trackEvent('markdown', 'export', pages.length);
}

function batchInit() {
  var globalData = {
    selectedPages: new Set()
  };
  document.addEventListener('click', function (e) {
    // 图片
    if (e.target.dataset.zoom) {
      BigPicture({
        el: e.target,
        imgSrc: e.target.src,
        animationEnd: function animationEnd() {}
      });
      return;
    }

    if (e.target.dataset.snapshot) {
      BigPicture({
        el: e.target,
        imgSrc: e.target.dataset.snapshot,
        animationEnd: function animationEnd() {}
      });
      return;
    } // 选中


    var key = e.target.dataset.key;
    if (!key) return;
    var checked = e.target.checked;

    if (checked) {
      globalData.selectedPages.add(key);
    } else {
      globalData.selectedPages["delete"](key);
    }

    document.getElementById('selectedCount').innerText = globalData.selectedPages.size.toString();
  });
  var checkbox = document.getElementById('batch-checkbox');
  checkbox.addEventListener('change', function (e) {
    [].forEach.call(document.querySelectorAll('.page-check'), function (el) {
      if (e.currentTarget.checked !== el.checked && getComputedStyle(el.parentNode).display !== 'none') {
        el.click();
      }
    });
    e.stopPropagation();
  });

  document.getElementById('batch-export').onclick = function () {
    var pages = Array.from(globalData.selectedPages).map(function (key) {
      return pageObject[key];
    });
    exportMd(pages);
  };

  document.getElementById('batch-delete').onclick = function () {
    var deleteKeys = globalData.selectedPages;
    if (deleteKeys.size === 0) return;
    message.sendMessageToBack('delete_pages', {
      keys: Array.from(deleteKeys)
    }, function (result) {
      window.location.reload();
    });
  };

  document.getElementById('more-status').onchange = function (e) {
    var tags = document.getElementById('tags');

    if (e.currentTarget.checked) {
      tags.classList.add('batch');
    } else {
      tags.classList.remove('batch');
    }
  };
}

function initBackup() {
  var element = document.getElementById('export-meta');

  if (element) {
    element.onclick = function () {
      exportFile(element);
    };
  }

  var importEl = document.getElementById('import-data');

  if (importEl) {
    importEl.onchange = function () {
      var selectedFile = document.getElementById('import-data').files[0]; // var name = selectedFile.name;//读取选中文件的文件名
      // var size = selectedFile.size;//读取选中文件的大小

      var reader = new FileReader(); //这是核心,读取操作就是由它完成.

      reader.readAsText(selectedFile); //读取文件的内容,也可以读取文件的URL

      reader.onload = function () {
        trackEvent('backup', 'import');
        var datas = null;

        try {
          datas = JSON.parse(decodeURIComponent(this.result));
        } catch (e) {
          alert('解析错误，请检查备份文件是否有损坏');
        }

        if (datas) {
          var result = window.confirm('确认导入？可能会覆盖现有数据');

          if (result) {
            message.sendMessageToBack('import_data', {
              datas: datas
            }, function () {
              loadData();
              alert('导入成功');
            });
          }
        }
      };
    };
  }
}

function exportFile(element) {
  if (!storeDatas) {
    return;
  }

  var exportKey = element.dataset.exportkey;
  var exportData = exportKey ? _defineProperty({}, exportKey, storeDatas[exportKey]) : storeDatas;
  trackEvent('backup', 'export', getCurrentVersion(), 0);
  funDownload(encodeURIComponent(JSON.stringify(exportData)), "pagenote_".concat(getCurrentVersion(), ".json"));
}

;
formatI18n();

if (window.sendPageView) {
  setTimeout(function () {
    sendPageView();
  }, 1000);
}
