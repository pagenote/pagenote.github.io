"use strict";

// injected check 不放到document_start 是因为避免dom元素还未渲染出来，导致判断是否已经载入pagenote错误
if (window.top === window) {
  var injectMessage = new Message('script');
  var injectByUs = false;
  var hasPageNote = !!document.querySelector('*[data-pagenote]');

  if (!hasPageNote || !window.pagenote) {
    // 如果网站已经存在pagenote则不
    injectMessage.sendMessageToBack('inject_to_tab', {}, function (result) {
      if (result.success) {
        injectByUs = true;
      }
    });
  }

  injectMessage.addListener('get_current_page_status', function (request, sender, sendResponse) {
    var status = {
      injected: hasPageNote,
      // 已经有其他pagenote注入过
      available: !!document.querySelector('*[data-pagenote]'),
      lightCnt: window.pagenote && window.pagenote.recordedSteps ? window.pagenote.recordedSteps.length : null,
      url: window.location.href,
      keys: getStoreKeys()
    };
    injectMessage.sendMessageToBack('on_get_current_page_status', status);
  });
}

function getStoreKeys() {
  var pathname = window.location.pathname || '/';
  pathname = pathname[pathname.length - 1] === '/' ? pathname : pathname + '/';
  return [window.location.host, pathname]; // ,window.location.search,window.location.hash
}
