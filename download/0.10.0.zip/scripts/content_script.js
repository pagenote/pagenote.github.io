"use strict";

var message = new Message('front');
var sendMessageToBack = message.sendMessageToBack;
var hasPageNote = !!document.querySelector('*[data-pagenote]');

function initPageNote() {
  var noInit = window.pagenote !== undefined || hasPageNote || document.body.dataset.nopagenote;
  if (noInit) return;
  var lastTarget = {};
  document.addEventListener('mousedown', function (e) {
    lastTarget = e;
  });
  message.addListener('export', function (request) {
    createShare(window.pagenote);
  }).addListener('toggleAllLight', function () {
    window.pagenote.toggleAllLight();
  }).addListener('togglePagenote', function (request, sender, sendResponse) {
    togglePagenote(request.status);
  }).addListener('record', function (_ref) {
    var tab = _ref.tab,
        info = _ref.info,
        record_type = _ref.record_type,
        selected = _ref.selected;
    var params = selected ? null : {
      id: 'body',
      tip: getLocale('create_light_in_page'),
      x: lastTarget.pageX,
      y: lastTarget.pageY,
      text: window.location.href,
      time: new Date().getTime(),
      isActive: true,
      bg: 'rgba(0,0,0,0.5)'
    };
    window.pagenote.record(params, true);
  }).addListener('on_capture', function (request, sender, sendResponse) {
    doCapure(request);
  }).addListener('sync_user_info', function (request) {
    syncUser(request.token, request.user);
  }).addListener('on_get_setting', function (request) {
    var _request$data = request.data,
        colors = _request$data.colors,
        _request$data$maxReco = _request$data.maxRecord,
        maxRecord = _request$data$maxReco === void 0 ? 20 : _request$data$maxReco,
        matchType = _request$data.matchType;
    window.pagenote = new PageNote("pagenote-extension", {
      saveInURL: false,
      saveInLocal: false,
      colors: colors,
      maxMarkNumber: maxRecord,
      onShare: createShare,
      functionColors: [{
        icon: chrome.runtime.getURL('images/icons/camera.png'),
        bgColor: '#fff',
        name: 'camera',
        onclick: function onclick() {
          sendMessageToBack('capture', {
            isAuto: false
          });
          tarckAction(['function', 'capture', '', '2']);
        }
      }, {
        icon: chrome.runtime.getURL('images/icons/copy.png'),
        bgColor: '#fff',
        name: 'copy',
        onclick: function onclick(e) {
          var text = pagenote.target ? pagenote.target.text : '';

          if (text) {
            writeTextToClipboard(text);
            pagenote.status = pagenote.CONSTANT.READY;
            var position = {
              x: e.clientX + 'px',
              y: e.clientY + 'px'
            };
            pagenote.notification("\u590D\u5236\u6210\u529F\uFF0C\u53BB\u7C98\u8D34\u4F7F\u7528\u5427\u3002<b>\u3010".concat(text, "\u3011</b>"), 'success', 3000, position);
          }

          tarckAction(['function', 'copy', '', '1']);
        }
      }]
    });
    window.pagenote._token = request.token;
    window.pagenote._user = request.currentUser; // let timers = 0;

    message.addListener('on_get_data', function (request, sender, sendResponse) {
      // if(timers>1) return;
      var data = request.data;
      pagenote.init(data, false);
      sendResponse({
        success: true
      }); // if(!data){
      //     timers++;
      //     queryPageData();
      // }
    });
    queryPageData();
    window.pagenote.addListener(function (status) {
      var count = pagenote.recordedSteps.length;
      var activeCount = 0;
      pagenote.recordedSteps.forEach(function (step) {
        if (step.isActive) {
          activeCount++;
        }
      });
      var text = count ? count + '' : '';
      var color = count ? pagenote.recordedSteps[count - 1].bg || '#72D0FF' : '#72D0FF';

      switch (status) {
        case pagenote.CONSTANT.RECORDING:
          // sendMessageToBack('capture');
          break;

        case pagenote.CONSTANT.READY:
          setBadge(text, color); // if(count===0 && !pagenote.isLikeMode){
          //     searchAlike();
          // }

          break;

        case pagenote.CONSTANT.SYNCED:
          message.sendMessageToBack('save_info', {
            data: pagenote.plainData ? undefined : pagenote.data,
            key: getStoreKey(),
            keys: getStoreKeys(),
            plainData: pagenote.plainData.steps.length || pagenote.plainData.snapshots.length ? pagenote.plainData : null
          });
          setBadge(text, color);
          break;

        case pagenote.CONSTANT.RECORDED:
          sendMessageToBack('capture', {
            isAuto: true
          });
          tarckAction(['light', 'record', 'new', pagenote.recordedSteps.length]);
          break;

        case pagenote.CONSTANT.REMOVED:
          tarckAction(['light', 'remove']);
          break;

        case pagenote.CONSTANT.REMOVEDALL:
          tarckAction(['light', 'removeAll']);
          break;
      }
    });
  }).sendMessageToBack('get_setting');

  function syncUser(token, user) {
    window.pagenote._token = token;
    window.pagenote._user = user;

    window.pagenote._syncModal();
  }
}

function listenUrl() {
  var initUrl = getStoreKey();
  var timer = new Date();
  setInterval(function () {
    var beforeLastTime = new Date() - timer;

    if (initUrl !== getStoreKey() && beforeLastTime > 500) {
      timer = new Date();
      initUrl = getStoreKey();
      queryPageData();
    }
  }, 2000);
  document.addEventListener('click', function () {
    if (initUrl !== window.location.href) {
      timer = new Date();
      setTimeout(function () {
        queryPageData();
      }, 100);
    }
  });
}

function getStoreKey() {
  return window.location.href;
}

function getStoreKeys() {
  var pathname = window.location.pathname || '/';
  pathname = pathname[pathname.length - 1] === '/' ? pathname : pathname + '/';
  return [window.location.host, pathname]; // ,window.location.search,window.location.hash
}

function queryPageData() {
  sendMessageToBack('get_data', {
    key: getStoreKey(),
    keys: getStoreKeys()
  });
}

function tarckAction() {
  var info = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
  sendMessageToBack('trackEvent', {
    trackInfo: info
  });
}

function setBadge(badge, color) {
  message.sendMessageToBack('set_badge', {
    badge: badge.toString(),
    color: color
  });
}

function searchAlike() {
  message.sendMessageToBack('search_likes', {
    keys: getStoreKeys()
  }, function (_ref2) {
    var likeItems = _ref2.likeItems;

    if (likeItems.length) {
      setBadge('?' + likeItems.length, 'blue');
      var likeItem = likeItems[0];
      var data = pagenote.decodeData(likeItem.data);
      var sameTitle = (document.querySelector('title') || {}).innerText === data.title;
      var sameIcon = getWebIcon() === data.icon;
      var matchRate = 0;

      if (sameTitle && sameIcon && data.steps && data.steps.length) {
        var matchStep = 0;
        data.steps.forEach(function (step) {
          var eid = step[2];
          var keyword = step[3];
          var element = document.getElementById(eid) || document.querySelector(eid);

          if (element) {
            matchStep += 0.5;
          }

          if (element && element.innerText.indexOf(keyword) > -1) {
            matchStep += 0.5;
          }
        });
        matchRate = matchStep / data.steps.length;
      }

      if (matchRate > 0.2) {
        pagenote.isLikeMode = true;
        pagenote.init(likeItem.data, true);
        message.sendMessageToBack('save_info', {
          key: likeItem.key,
          data: null
        });
      } // pagenote.init(likeItems[0].data,false,likeItems[0].key)

    }
  });
}

function getWebIcon() {
  var iconEle = document.querySelector('link[rel~=icon]');
  return iconEle ? iconEle.href : window.location.origin + '/favicon.ico';
}

var sendShareData = {};
var lisented = false;
var sharePage = null;

function createShare(pagenote, callback) {
  tarckAction(['function', 'share', getCurrentVersion(), 1]);
  pagenote.makelink(function (shareData) {
    sendShareData = generateHTMLData(shareData);
    sendShareData.markdown = pagenote.generateMD();
    var left = window.innerWidth / 2 - 400;
    sharePage = window.open('https://pagenote.logike.cn/share', 'share', "width=800,height=500,top=100,left=".concat(left, ",status=no,location=no"));
    sharePage.focus();
    setTimeout(function () {
      sharePage.postMessage({
        type: 'sync_shareInfo',
        shareData: sendShareData
      }, '*');
    }, 1000);

    if (lisented === false) {
      var receiveMessage = function receiveMessage(event) {
        if (event.data.type === "get_share_data") {
          sharePage.postMessage({
            type: 'sync_shareInfo',
            shareData: sendShareData
          }, '*');
        }
      };

      window.addEventListener("message", receiveMessage, false);
      lisented = true;
    }
  });

  function doShare() {
    if (!window.pagenote._token) {
      var host = 'https://pagenote.logike.cn?form=extension';
      var left = window.innerWidth / 2 - 300;
      var loginWindow = window.open("https://github.com/login/oauth/authorize?scope=user%20public_repo&client_id=c4aae381097464aa1024&redirect_uri=".concat(host), '', "width=600,height=600,top=0,left=".concat(left, ",status=no,location=no"));
      loginWindow.focus();
    }

    axios({
      method: 'post',
      headers: {
        Accept: 'application/json',
        Authorization: "token ".concat(window.pagenote._token)
      },
      url: "https://api.github.com/repos/rowthan/pagenote/issues",
      data: {
        title: plainData.title,
        body: JSON.stringify(plainData),
        labels: ['pagenote']
      }
    }).then(function (response) {
      callback({
        errorMsg: (response.errors || [{}])[0].message,
        success: true,
        data: response.data,
        shareLink: "https://pagenote.logike.cn/snapshot?pagenote=".concat(response.data.number)
      });
    })["catch"](function (response) {
      callback({
        success: false,
        data: response.data,
        errorMsg: (response.errors || [{}])[0].message || '创建分享链接失败，请刷新页面后重试或尝试「仅分享标记」。',
        shareLink: ''
      });
    });
  }

  function generateHTMLData(lightData) {
    var forShareData = JSON.parse(JSON.stringify(lightData));
    var doc = document.documentElement.cloneNode(true);
    [].forEach.call(doc.querySelectorAll('script'), function (el) {
      el.parentNode.removeChild(el);
    });
    [].forEach.call(doc.querySelectorAll('*[data-pagenote]'), function (el) {
      el.parentNode.removeChild(el);
    });
    [].forEach.call(doc.querySelectorAll('pagenote-modal'), function (el) {
      el.parentNode.removeChild(el);
    });
    [].forEach.call(doc.querySelectorAll('style[pagenote]'), function (el) {
      el.parentNode.removeChild(el);
    });
    [].forEach.call(doc.querySelectorAll('iframe'), function (el) {
      el.parentNode.removeChild(el);
    });
    [].forEach.call(doc.querySelectorAll('iframe'), function (el) {
      el.parentNode.removeChild(el);
    });
    doc.querySelectorAll("light[data-highlight]").forEach(function (light) {
      light.outerHTML = light.innerHTML;
    });
    doc.querySelectorAll('link').forEach(function (s) {
      replaceResource(s, 'href');
    });
    doc.querySelectorAll('img').forEach(function (s) {
      replaceResource(s, 'src');
    });

    function replaceResource(s) {
      var key = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'href';
      var href = s.getAttribute(key); // 替换相对路径

      if (/^\./.test(href)) {
        href = href.replace('./', window.location.pathname);
      } // 增加域名


      if (!/^http/.test(href)) {
        href = window.location.protocol + '//' + window.location.host + href;
        s.setAttribute(key, href);
      }
    }

    forShareData.html = doc.outerHTML.replace(/\s+|\n/g, function (match) {
      return ' ';
    });
    return forShareData;
  }
}

function togglePagenote(status) {
  var switchStatus = status === undefined ? pagenote.status === pagenote.CONSTANT.DESTROY : status;

  if (switchStatus) {
    pagenote.realive();
  } else {
    pagenote.destroy();
  }

  syncPageStatus();
}

function syncLoginToken() {
  // 时刻同步线上的登录状态
  if (window.location.host === 'pagenote.logike.cn') {
    var token = localStorage.getItem('token') || '';
    sendMessageToBack('sync-token', {
      token: token
    }, function () {
      var search = window.location.search;

      if (search.indexOf('form=extension') > -1 && search.indexOf('code') === -1) {
        window.close();
      }
    });
  }
}

function doCapure(request) {
  var isAuto = request.isAuto;
  var canPhoto = isAuto === true && window.pagenote.snapshots.length === 0 || isAuto === false;

  if (canPhoto) {
    if (window.pagenote.snapshots.length > 4) {
      alert(getLocale('snapshot_reached_the_upper_limit'));
      return;
    }

    var snapshot = request.snapshot;
    window.pagenote.snapshots.push(snapshot);
    var last = document.querySelector('pagenote-camera');

    if (last) {
      last.parentNode.removeChild(last);
    }

    var camera = document.createElement('pagenote-camera');
    window.pagenote.makelink(function () {
      //<button>滚动一屏，再拍一张</button>
      if (isAuto === false) {
        var destoryCa = function destoryCa() {
          camera.parentNode.removeChild(camera);
          clearInterval(timer);
        };

        var tip = window.pagenote.snapshots.length + '个快照';
        camera.innerHTML = "<div class='pagenote-camera-container'>\n                                  <div class='camera-top'>\n                                    <div class='zoom'></div>\n                                    <div class='mode-changer'></div>\n                                    <div class='sides'></div>\n                                    <div class='range-finder'></div>\n                                    <div class='focus'></div>\n                                    <div class='red'></div>\n                                    <div class='view-finder'></div>\n                                    <div class='flash'>\n                                      <div class='light'></div>\n                                    </div>\n                                  </div>\n                                  <div class='camera-mid'>\n                                    <div class='sensor'></div>\n                                    <div class='lens'></div> \n                                    <div class=\"tip\"><div>\u5DF2\u62CD\u7167\u5B8C\u6210\u5E76\u4FDD\u5B58\uFF0C\u4F60\u53EF\u4EE5\u5728\u7BA1\u7406\u9875\u8FDB\u884C\u67E5\u770B\u3001\u7F16\u8F91\u3002</div><button><a target=\"_blank\" href=\"https://pagenote.logike.cn/me\">\u524D\u5F80\u67E5\u770B".concat(tip, "</a></button><button id=\"close-camera\">\u5173\u95ED\u6444\u50CF\u673A<span id=\"count-down\">8s</span></button></div>\n                                  </div>\n                                  <div class='camera-bottom'></div>\n                                  <div class=\"camera-picture\"><img src=").concat(snapshot, " alt=\"\"></div>\n                                </div>");
        document.body.appendChild(camera);
        var time = 8;
        var timer = setInterval(function () {
          document.getElementById('count-down').innerText = time + 's';
          time--;

          if (time <= 0) {
            destoryCa();
          }
        }, 1000);
        ;
        document.getElementById('close-camera').onclick = destoryCa;
      }
    });
  }
}

initPageNote();
listenUrl();
syncLoginToken();
message.addListener('get_current_page_status', function () {
  syncPageStatus();
});
message.addListener('save_page_note', function (_ref3) {
  var note = _ref3.note;
  note = note.trim();
  var body = null;
  var bodyIndex = -1;

  for (var i = 0; i < pagenote.recordedSteps.length; i++) {
    if (pagenote.recordedSteps[i].id === 'root') {
      body = pagenote.recordedSteps[i];
      bodyIndex = i;
      break;
    }
  }

  if (body) {
    body.tip = note;

    if (note === '') {
      pagenote.remove(bodyIndex);
    }

    pagenote.makelink();
  } else if (note) {
    pagenote.record({
      id: 'root',
      tip: note,
      bg: '#ffc60a'
    }, true);
  }
});

function syncPageStatus() {
  var status = {
    injected: hasPageNote,
    // 已经有其他pagenote注入过 全部认为未注入 ['logike.cn','pagenote.logike.cn'].includes(window.location.host)
    available: !!window.pagenote && window.pagenote.status > -1,
    lightCnt: window.pagenote && window.pagenote.recordedSteps ? window.pagenote.recordedSteps.length : null,
    url: window.location.href,
    keys: getStoreKeys(),
    notes: window.pagenote ? window.pagenote.recordedSteps : []
  };
  sendMessageToBack('on_get_current_page_status', status);
}
