"use strict";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

var STORE_KEY = 'pagenote-data';
var SETTING_KEY = 'pagenote-setting';
var NotificationKey = 'updateLogId';
var proxy = 'https://cors-anywhere.herokuapp.com/';
var notificationInfo = null;
var currentSetting = null; // TODO 优化get——setting

var openUrl = chrome.runtime.getURL('option.html'); // 'https://pagenote.logike.cn/';//chrome.runtime.getURL('option.html');

var welcomeUrl = chrome.runtime.getURL('option.html') + '#privacy'; //'https://pagenote.logike.cn/hello';

var uninstallUrl = 'https://pagenote.logike.cn/uninstall';
var currentUser = null;
var currentToken = '';

function getRecommendSetting() {
  return {
    themeId: 'theme-default',
    colors: ['rgba(114,208,255,0.88)', '#ffbea9', '#c8a6ff', '#6fe2d5', 'rgba(255,222,93,0.84)', 'rgba(251, 181, 214, 0.84)', 'rgba(0,0,0,0.5)'],
    maxRecord: 30,
    openInTab: false,
    matchType: 'smart'
  };
}

var currentData = null;

function getCurrentData(callback) {
  if (currentData) {
    return callback(currentData);
  } else {
    getLocalData(STORE_KEY, function (result) {
      currentData = result;
      callback(currentData);
    });
  }
}

(function () {
  getLocalData(SETTING_KEY, function (result) {
    currentSetting = result;
  });
})();

var message = new Message('background');
var listener = message.addListener;
var sendToFront = message.sendMessageToFrontEnd;
var sendToBack = message.sendMessageToBack;
listener('set_badge', function (request, sender, sendResponse) {
  var badge = request.badge;
  var color = request.color;
  setBadgeText(badge, sender.tab.id);
  chrome.browserAction.setBadgeBackgroundColor({
    color: color,
    tabId: sender.tab.id
  });
});
listener('delete_pages', function (request, sender, sendResponse) {
  var keys = request.keys;
  getCurrentData(function (data) {
    keys.forEach(function (key) {
      delete data[key];
    });
    savePagesData(data, {
      keys: keys,
      action: 'delete',
      pages: []
    });
    sendResponse({
      success: true
    });
  });
});
listener('save_info', function (request, sender, sendResponse) {
  var data = request.data || '';
  var datakey = request.key;
  var likeKeys = request.keys;
  var plainData = request.plainData;

  if (data) {
    trackEvent('old', 'save_old_data', '不兼容的数据格式');
  }

  getCurrentData(function (originData) {
    var actionType = '';

    if (data || plainData) {
      originData[datakey] = {
        data: data,
        // todo 删除
        plainData: plainData,
        keys: likeKeys
      };
      actionType = 'update';
    } else {
      actionType = 'delete';
      delete originData[datakey];
    }

    savePagesData(originData, {
      keys: [datakey],
      action: actionType,
      pages: [plainData]
    });
    sendResponse({
      success: true,
      data: originData
    });
  });
});
listener('import_data', function (request, sender, sendResponse) {
  var datas = request.datas;
  getCurrentData(function (originData) {
    Object.keys(datas).forEach(function (key) {
      originData[key] = datas[key];
    });
    savePagesData(originData);
    sendResponse({
      success: true
    });
  });
});
listener('search_likes', function (request, sender, sendResponse) {
  var likeItems = searchLike(request.keys);
  sendResponse({
    likeItems: likeItems
  });
});
listener('get_data', function (request, sender, sendResponse) {
  getCurrentData(function (originData) {
    processData(originData);
  });

  function processData() {
    var allData = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var storeInfo = allData[request.key];
    var responseData = _typeof(storeInfo) === 'object' ? storeInfo.data : storeInfo; // TODO 兼容性代码

    var plainData = _typeof(storeInfo) === 'object' ? storeInfo.plainData : null;
    var finalData = plainData || responseData;
    sendToFront('on_get_data', {
      data: finalData
    }, null, sender.tabId);

    if (finalData) {
      // 如果当前页有数据
      setAvaliable(true);
    }
  }
});
listener('get_pagenote_data', function (request, sender) {
  getCurrentData(function (result) {
    chrome.tabs.query({
      active: true,
      currentWindow: true
    }, function (tabs) {
      var tab = tabs[0];
      var info = {
        data: result,
        requestClient: request.client // currentUrl: tab.url,

      };
      sendToFront('on_get_pagenote_data', info, null, sender.tab.id);
    });
  });
});
listener('get_data_store_key', function (request, sender, sendResponse) {
  sendResponse({
    key: STORE_KEY
  });
});
listener('get_setting', function (request, sender, sendResponse) {
  if (currentSetting && currentSetting.colors) {
    sendToFront('on_get_setting', {
      data: currentSetting,
      currentUser: currentUser,
      token: currentToken
    }, null, sender.tab.id);
  } else {
    getLocalData(SETTING_KEY, function (result) {
      currentSetting = result.colors ? result : getRecommendSetting();
      sendToFront('on_get_setting', {
        data: currentSetting
      }, null, sender.tab.id);
    });
  }
});

var capture = function capture(tabId, isAuto) {
  getCurrentTabId(function (id) {
    if (id !== tabId) {
      trackEvent('snapshot', 'capture', 'not-matched');
    }

    trackEvent('snapshot', 'capture', isAuto ? 'auto' : 'man');
    chrome.tabs.captureVisibleTab({
      format: 'jpeg',
      quality: 60
    }, function (screenshotUrl) {
      sendToFront('on_capture', {
        snapshot: screenshotUrl,
        isAuto: isAuto
      });
    });
  });
}; // 适合使用长连接


listener('capture', function (request, sender) {
  capture(sender.tab ? sender.tab.id : '', request.isAuto);
});
listener('save_setting', function (request, sender, sendResponse) {
  getLocalData(SETTING_KEY, function (result) {
    var newSetting = request.setting || getRecommendSetting();
    var newData = Object.assign(result, newSetting);
    storeLocalData(SETTING_KEY, newData);
    currentSetting = newData;
  });
});
listener('open_home', function () {
  window.open('https://pagenote.logike.cn/me?from=popup', 'pagenote_me');
}); // listener('inject_to_tab',function (request,sender,sendResponse) {
//     if(!checkTabRunScript(sender.url)){ // TODO 增加URL黑名单配置
//         sendResponse({success:false});
//         return;
//     }
//     // injectCss(["js/pagenote.css"],false,function () {
//     //
//     // });
//     executeScripts([
//         "lib/extension.js",
//         "lib/layer.js",
//         "lib/pagenote.js",
//         "scripts/content_script.js",],false,function () {
//         setAvaliable(true);
//     });
//     _gaq.push(['_trackPageview']);
//     sendResponse({success:true});
// });

listener('trackEvent', function (request, sender, sendResponse) {
  trackEvent.apply(void 0, _toConsumableArray(request.trackInfo || []));
});
listener('get_notification', function (request, sender, sendResponse) {
  sendResponse({
    notificationInfo: notificationInfo
  });
});
listener('read_notification_already', function (request, sender, sendResponse) {
  if (!notificationInfo) {
    return;
  }

  if (request.times) {
    notificationInfo.readTimes = request.times;
  }

  notificationInfo.readTimes++;
  localStorage.setItem(NotificationKey + '_read_times', notificationInfo.readTimes + '');

  if (notificationInfo.readTimes >= notificationInfo.show_times) {
    // 已阅读完，清空
    localStorage.setItem(NotificationKey, notificationInfo.id);
    localStorage.setItem(NotificationKey + '_read_times', '0');
    setBadgeText('');
    notificationInfo = null;
  }

  trackEvent('notification', 'read', '', request.times);
});
listener('get_user_info', function (request, sender, sendResponse) {
  sendResponse({
    user: currentUser,
    token: currentToken
  });
});
listener('sync-token', function (request, sender, sendResponse) {
  currentToken = request.token;

  if (!currentToken) {
    currentUser = null;
    sendToFront('sync_user_info', {
      user: currentUser,
      token: currentToken
    });
    return;
  }

  var times = 0;
  getUserFormServer();

  function getUserFormServer() {
    var useProxy = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;
    times++;

    if (times > 8) {
      return;
    }

    axios({
      method: 'get',
      headers: {
        Accept: 'application/json',
        Authorization: "token ".concat(currentToken)
      },
      url: "".concat(useProxy ? proxy : '', "https://api.github.com/user")
    }).then(function (response) {
      if (response.data) {
        currentUser = response.data;
      }

      sendToFront('sync_user_info', {
        user: currentUser,
        token: currentToken
      });
    })["catch"](function (e) {
      setTimeout(function () {
        getUserFormServer(!useProxy);
      }, 3000);
    });
  }

  sendResponse({
    success: true
  });
});
chrome.tabs.onActivated.addListener(function () {
  setTimeout(function () {
    sendToFront('sync_user_info', {
      user: currentUser,
      token: currentToken
    });
  }, 1000);
});
listener('on_get_current_page_status', function (request) {
  var injected = request.injected,
      available = request.available,
      lightCnt = request.lightCnt,
      keys = request.keys;
  setAvaliable(available);
}); // chrome.browserAction.onClicked.addListener(function(tab) {
//     chrome.tabs.query({
//         url: openUrl,
//     }, function(tabs){
//         if(tabs && tabs.length){
//             chrome.tabs.update(tabs[0].id,{
//                 active:true
//             })
//         }
//         else{
//             chrome.tabs.create({
//                 'url': openUrl,
//             });
//         }
//     })
//
//     // toggleLight()
// });

chrome.commands.onCommand.addListener(function (command) {
  switch (command) {
    case 'light':
      toggleLight();
      break;

    case 'share':
      chrome.tabs.executeScript(null, {
        code: 'createShare(window.pagenote)'
      });
      break;

    case 'switch':
      chrome.tabs.executeScript(null, {
        code: 'togglePagenote()'
      });
      break;

    case 'create':
      sendToFront('record', {});
      break;

    case 'snapshot':
      capture('', false);
      break;

    default:
  }
});
chrome.tabs.onCreated.addListener(function (tab) {
  // 覆盖新标签页
  if (currentSetting && currentSetting.openInTab) {
    if (tab.pendingUrl && tab.pendingUrl.indexOf('newtab') > -1 || tab.url === 'about:newtab') {
      chrome.tabs.update(tab.id, {
        'url': openUrl
      });
    }
  }

  var currentTime = new Date().getTime();
  var lastCheckTime = localStorage.getItem(NotificationKey + '_checkTime') || '0';

  if (currentTime - lastCheckTime > 3 * 24 * 60 * 60 * 1000) {
    checkUpdate();
  }
});
chrome.tabs.onUpdated.addListener(debounce(function (tab) {
  if (tab.url === openUrl) {
    setAvaliable(true);
  } else {
    sendToFront('get_current_page_status');
  }
}));
chrome.runtime.onInstalled.addListener(function () {
  chrome.tabs.create({
    'url': welcomeUrl
  });
  trackEvent('app', 'new_install');
});
chrome.runtime.setUninstallURL(uninstallUrl);
checkUpdate(); // omit();

function checkUpdate() {
  axios.get('https://logike.cn/pagenote.json').then(function (notifi) {
    var notification = notifi.data || [];
    localStorage.setItem(NotificationKey + '_checkTime', new Date().getTime() + '');

    for (var i = 0; i < notification.length; i++) {
      var result = notification[i] || {
        show_times: 1,
        for_max_version: 0,
        for_min_version: 0
      };
      var notified = localStorage.getItem(NotificationKey) || 0;
      var currentVersion = getCurrentVersion();
      var isLower = compareVersion(result.for_max_version, currentVersion) <= 0;
      var isHigher = compareVersion(result.for_min_version, currentVersion) >= 0;

      if (result.id <= notified) {
        // 已读完，不需要再提示
        notificationInfo = null;
      } else if (isLower && isHigher) {
        // 未读完、提示是否匹配当前版本
        notificationInfo = _objectSpread(_objectSpread({}, result), {}, {
          readTimes: +(localStorage.getItem(NotificationKey + '_read_times') || '0') // 已读次数

        });
        setBadgeText(result.badge || 'new', undefined, true);
        setAvaliable(true);
        break;
      } else {
        // 与当前无关的提示、不需要展示
        notificationInfo = null;
      }
    }

    trackEvent('release_note', 'fetch', 'success');
  })["catch"](function () {
    trackEvent('release_note', 'fetch', 'error');
  }); // return first >= second

  function compareVersion(first, second) {
    if (first === second) {
      return 0;
    }

    var firstVersion = first.split('.');
    var secondVersion = second.split('.');
    var large = -1;

    for (var i = 0; i < secondVersion.length; i++) {
      if (secondVersion[i] > firstVersion[i]) {
        large = 1;
        break;
      }
    }

    return large;
  }
}

function setBadgeText(text, tabId) {
  var forceUpdate = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
  // chrome.browserAction.getBadgeText({tabId:tabId},function (result) {
  //
  // });
  chrome.browserAction.setBadgeText({
    text: text,
    tabId: tabId
  });
}

function setAvaliable() {
  var available = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : true;
  getCurrentTabId(function (id) {
    var popup = available ? 'popup.html' : 'popup.html';
    var icon = available ? 'images/light-32.png' : 'images/light-disable.png';
    chrome.browserAction.setPopup({
      tabId: id,
      popup: popup
    });
    chrome.browserAction.setIcon({
      tabId: id,
      path: icon
    });
  });
}

function toggleLight() {
  trackEvent('lights', 'toggle');
  chrome.tabs.executeScript(null, {
    code: 'window.pagenote.toggleAllLight()'
  });
}

function searchLike(likeKeys) {
  // 模糊查询
  var matchType = currentSetting.matchType || 'smart';

  if (matchType === 'smart' && likeKeys.length) {
    // 智能 模糊查询
    var likeItems = [];
    getCurrentData(function (result) {
      Object.keys(result).forEach(function (key) {
        var item = result[key];

        if (item.keys && item.keys.toString() === likeKeys.toString()) {
          likeItems.push(_objectSpread({
            key: key
          }, item));
        }
      });
    });
    return likeItems;
  }

  return [];
}

function codeToToken(code, callback) {
  if (!code) {
    return;
    callback();
  }

  axios({
    method: 'post',
    headers: {
      Accept: 'application/json'
    },
    url: "".concat(proxy, "https://github.com/login/oauth/access_token"),
    data: {
      client_id: 'c4aae381097464aa1024',
      client_secret: 'ed40211bca3ccabd900586079b89fd0ec1ea48be',
      code: code[1]
    }
  }).then(function (response) {
    var token = response.data.access_token;
    localStorage.setItem('token', token);
    callback(token);
  });
}

function debounce(fn) {
  var interval = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 300;
  var timeout = null;
  return function () {
    var _arguments = arguments,
        _this = this;

    clearTimeout(timeout);
    timeout = setTimeout(function () {
      fn.apply(_this, _arguments);
    }, interval);
  };
}

function omit() {
  var currentRequest = null;
  chrome.omnibox.onInputChanged.addListener(function (text, suggest) {
    if (currentRequest != null) {
      currentRequest.onreadystatechange = null;
      currentRequest.abort();
      currentRequest = null;
    }

    updateDefaultSuggestion(text);
    if (text == '' || text == 'halp') return;
    currentRequest = search(text, function (xml) {
      var results = [{
        content: text,
        description: 'description'
      }];
      var entries = xml.getElementsByTagName("entry"); // for (var i = 0, entry; i < 5 && (entry = entries[i]); i++) {
      //     var path = entry.getElementsByTagName("file")[0].getAttribute("name");
      //     var line =
      //         entry.getElementsByTagName("match")[0].getAttribute("lineNumber");
      //     var file = path.split("/").pop();
      //
      //     var description = '<url>' + file + '</url>';
      //     if (/^file:/.test(text)) {
      //         description += ' <dim>' + path + '</dim>';
      //     } else {
      //         var content = entry.getElementsByTagName("content")[0].textContent;
      //
      //         // There can be multiple lines. Kill all the ones except the one that
      //         // contains the first match. We can ocassionally fail to find a single
      //         // line that matches, so we still handle multiple lines below.
      //         var matches = content.split(/\n/);
      //         for (var j = 0, match; match = matches[j]; j++) {
      //             if (match.indexOf('<b>') > -1) {
      //                 content = match;
      //                 break;
      //             }
      //         }
      //
      //         // Replace any extraneous whitespace to make it look nicer.
      //         content = content.replace(/[\n\t]/g, ' ');
      //         content = content.replace(/ {2,}/g, ' ');
      //
      //         // Codesearch wraps the result in <pre> tags. Remove those if they're
      //         // still there.
      //         content = content.replace(/<\/?pre>/g, '');
      //
      //         // Codesearch highlights the matches with 'b' tags. Replaces those
      //         // with 'match'.
      //         content = content.replace(/<(\/)?b>/g, '<$1match>');
      //
      //         description += ' ' + content;
      //     }
      //
      //     results.push({
      //         content: path + '@' + line,
      //         description: description
      //     });
      // }

      suggest(results);
    });
  });

  function resetDefaultSuggestion() {
    chrome.omnibox.setDefaultSuggestion({
      description: '<url><match>find:</match></url> Search in pagenote'
    });
  }

  resetDefaultSuggestion();

  function updateDefaultSuggestion(text) {
    var description = '<match><url>find</url></match><dim>:</dim>';
    description += '<match>' + text + '</match>';
    chrome.omnibox.setDefaultSuggestion({
      description: description
    });
  }

  chrome.omnibox.onInputStarted.addListener(function () {
    updateDefaultSuggestion('');
  });
  chrome.omnibox.onInputCancelled.addListener(function () {
    resetDefaultSuggestion();
  });

  function search(query, callback) {
    if (query == 'halp') return;
    if (/^re:/.test(query)) query = query.substring('re:'.length);else if (/^file:/.test(query)) query = 'file:"' + query.substring('file:'.length) + '"';else query = '"' + query + '"';
    var url = "https://code.google.com/p/chromium/codesearch#search/&type=cs&q=" + query + "&exact_package=chromium&type=cs";
    var req = new XMLHttpRequest();
    req.open("GET", url, true);
    req.setRequestHeader("GData-Version", "2");

    req.onreadystatechange = function () {
      if (req.readyState == 4) {
        callback(req.responseXML);
      }
    };

    req.send(null);
    return req;
  }

  function getUrl(path, line) {
    var url = "https://code.google.com/p/chromium/codesearch#" + path;
    "&sq=package:chromium";
    if (line) url += "&l=" + line;
    return url;
  }

  function getEntryUrl(entry) {
    return getUrl(entry.getElementsByTagName("file")[0].getAttribute("name"), entry.getElementsByTagName("match")[0].getAttribute("lineNumber"));
    return url;
  }

  function navigate(url) {
    chrome.tabs.query({
      active: true,
      currentWindow: true
    }, function (tabs) {
      chrome.tabs.update(tabs[0].id, {
        url: url
      });
    });
  }

  chrome.omnibox.onInputEntered.addListener(function (text) {
    // TODO(aa): We need a way to pass arbitrary data through. Maybe that is just
    // URL?
    if (/@\d+\b/.test(text)) {
      var chunks = text.split('@');
      var path = chunks[0];
      var line = chunks[1];
      navigate(getUrl(path, line));
    } else if (text == 'halp') {// TODO(aa)
    } else {
      navigate("https://code.google.com/p/chromium/codesearch#search/&type=cs" + "&q=" + text + "&exact_package=chromium&type=cs");
    }
  });
}

getBookTree();
var rootBook = isFirefox() ? 'toolbar_____' : '1';

function savePagesData(pageData) {
  var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {
    keys: [],
    action: 'update',
    pages: []
  };
  storeLocalData(STORE_KEY, pageData);
  var pageBook = null;
  chrome.bookmarks.search({
    title: 'pagenote',
    url: undefined
  }, function (result) {
    pageBook = result.find(function (item) {
      return item.parentId === rootBook;
    });

    if (!pageBook) {
      chrome.bookmarks.create({
        parentId: rootBook,
        index: 0,
        title: 'pagenote'
      }, function (result) {
        pageBook = result;
        chrome.bookmarks.create({
          parentId: pageBook.id,
          index: 0,
          title: '此目录下的网页由pagenote自动创建',
          url: "https://pagenote.logike.cn/auto_bookmark"
        });
        chrome.bookmarks.create({
          parentId: pageBook.id,
          index: 1,
          title: '查看我的PAGENOTE',
          url: "https://pagenote.logike.cn/me?utm_source=bookmark"
        });
        syncToBookmark();
      });
    } else {
      syncToBookmark();
    }
  });

  function syncToBookmark() {
    switch (action.action) {
      case 'delete':
        action.keys.forEach(function (key) {
          chrome.bookmarks.search({
            url: key
          }, function (result) {
            result.forEach(function (bookmark) {
              if (bookmark.parentId === pageBook.id) {
                chrome.bookmarks.remove(bookmark.id);
              }
            });
          });
        });
        break;

      case 'update':
        // 姑且只考虑新增的情况
        action.keys.forEach(function (key, index) {
          var pageItem = action.pages[index];
          chrome.bookmarks.search({
            url: key
          }, function (result) {
            var matchedCnt = 0;
            result.forEach(function (bookmark) {
              if (bookmark.parentId === pageBook.id) {
                matchedCnt++;
                chrome.bookmarks.update(bookmark.id, {
                  title: "".concat(pageItem.steps.length, "\uD83D\uDCD2").concat(pageItem.snapshots.length, "\uD83D\uDCF7 | ").concat(pageItem.title)
                });
              }
            }); // 新增

            if (matchedCnt === 0) {
              chrome.bookmarks.create({
                parentId: pageBook.id,
                index: 1,
                title: "".concat(pageItem.steps.length, "\uD83D\uDCD2").concat(pageItem.snapshots.length, "\uD83D\uDCF7 | ").concat(pageItem.title),
                url: key
              });
            }
          });
        });
        break;

      default:
    }
  }
}

function getBookTree() {
  chrome.bookmarks.getTree(function (result) {
    console.log(result);
  });
}

chrome.contextMenus.removeAll();
var menus = new Map([[['all'], [{
  id: 'capture',
  onclick: function onclick(info, tab) {
    capture(tab.id, false);
  }
}]], [['page'], [{
  id: 'create_light_in_page',
  onclick: function onclick(info, tab) {
    sendToFront('record', {
      info: info,
      tab: tab
    });
  }
} // {
//     id: 'export_page',
//     onclick:function (info,tab) {
//         sendToFront('export',{
//             actionType:'share'
//         });
//     }
// },
// { id: 'delete_all',
//     onclick:function (info,tab) {
//         sendToFront('deleteAll',{
//             info,tab
//         });
//     }}
]] // , [['frame'], [
//     { id: 'EXPORT_MARKDOWN_ALL' }
// ]]
, [['selection'], [// 快捷键操作 m
{
  id: 'create_light',
  onclick: function onclick(info, tab) {
    sendToFront('record', {
      info: info,
      tab: tab,
      selected: true
    });
  }
}]] // , [['link'], [
//     { id: 'link' }
// ]]
// , [['editable'], [
//     { id: 'editable' }
// ]]
// , [['image'], [
//     { id: 'record_this_image',
//         onclick:function (info,tab) {
//             sendToFront('record',{
//                 record_type: 'image',
//                 info:info,
//                 tab: tab,
//             });
//         }
//     }
// ]]
// , [['audio'], [
//     { id: 'audio' }
// ]]
// , [['video'], [
//     { id:'VIDEO'}
// ]]
, [['browser_action'], [{
  id: 'donation',
  onclick: function onclick(info, tab) {
    window.open('https://pagenote.logike.cn/donation');
  }
}]]]);
createMenus(menus);
